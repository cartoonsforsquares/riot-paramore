Riot: a hand-drawn fan font in three styles (Marker, Scrawl, Scribble).

Install
- Mac: double-click each .otf file, then click Install Font.
- Windows: right-click each .otf file and choose Install.
- Procreate: Actions > Add > Add Text, then Edit Style > Import Font.

All three styles appear under the family name "Riot".
Capitals only: lowercase keys type the capitals too.
